<?php include "inc/helpers.php"; ?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head> <meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 
<meta name="description" content="<?php echo $page_desc; ?>"> 
<meta name="keywords" content="<?php echo $page_keys; ?>"> 
<meta name="theme-color" content="#ffffff"><link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<title><?php echo $page_title; ?></title> 
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"> <link href="https://ebddacdn.s3.eu-central-1.amazonaws.com/css/heroic-features.css" rel="stylesheet"><meta property="og:title" content="انشيء موقعك الإلكتروني | ابدأ"><meta property="og:type" content="product"><meta property="og:description" content="استضافة مواقع, نطاقات, بريد إلكتروني وأمن المواقع"><meta property="og:image" content="">

<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script src="bootstrap-input-spinner.js"></script>

</head><body> <nav class="navbar navbar-expand-lg navbar-light"> <div class="container"> <a class="navbar-brand" href="/"><img src="vendor/img/logo.png" height="30" width="30" alt="<?php echo $page_title; ?>"> ابدأ لخدمات الويب</a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button> <div class="collapse navbar-collapse" id="navbarResponsive"> <ul class="navbar-nav">
<?php foreach($nav_links as $link => $value) { echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"$link\">$value</a></li>";} ?> </ul> </div></div></nav> <header class="jumbotron <?php if($catg){echo $catg;}?>"><div class="container px-0"><div class="row"><div class="hero col-sm-6"> <h1><?php echo $hero_text; ?></h1> <p class="lead"><?php echo $hero_desc; ?></p><ul> <li><i class="fa fa-check"></i> <?php echo $li_txt1; ?></li><li><i class="fa fa-check"></i> <?php echo $li_txt2; ?></li><li><i class="fa fa-check"></i> <?php echo $li_txt3; ?></li></ul> <a href="<?php echo $btn_lnk; ?>" class="btn btn-lg btn-primary btn-cta"><?php echo $btn_text; ?></a> </div><div class="col-sm-6 col-media"> <p></p></div></div></div></header>